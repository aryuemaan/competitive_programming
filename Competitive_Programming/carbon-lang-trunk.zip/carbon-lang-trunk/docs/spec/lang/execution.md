# Execution

<!--
Part of the Carbon Language project, under the Apache License v2.0 with LLVM
Exceptions. See /LICENSE for license information.
SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
-->

## Entry points

TODO: Entry points (Carbon and foreign). `fn Run()`.

## Object model

## Sequential execution

## Threads and data races

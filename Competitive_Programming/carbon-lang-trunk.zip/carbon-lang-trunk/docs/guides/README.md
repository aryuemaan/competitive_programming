# Guides

<!--
Part of the Carbon Language project, under the Apache License v2.0 with LLVM
Exceptions. See /LICENSE for license information.
SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
-->

This directory contains end-user documentation on how to use Carbon, focused on
people trying to use and write code in Carbon.

-   [Glossary](glossary.md)
